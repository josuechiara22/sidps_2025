define({
  "_widgetLabel": "Kontrolnik Škatle"
});