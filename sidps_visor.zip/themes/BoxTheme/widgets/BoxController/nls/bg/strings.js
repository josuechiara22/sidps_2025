define({
  "_widgetLabel": "Box контролер"
});