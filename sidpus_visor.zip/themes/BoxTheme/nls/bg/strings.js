define({
  "_themeLabel": "Тема \"Кутия\"",
  "_layout_default": "Оформление по подразбиране",
  "_layout_top": "Горно оформление"
});