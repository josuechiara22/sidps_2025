define({
  "_themeLabel": "ボックス テーマ",
  "_layout_default": "デフォルトのレイアウト",
  "_layout_top": "上位のレイアウト"
});