define({
  "_themeLabel": "Motív Box",
  "_layout_default": "Predvolené rozloženie",
  "_layout_top": "Horné rozloženie"
});