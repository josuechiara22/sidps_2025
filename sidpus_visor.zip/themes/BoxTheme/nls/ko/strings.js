define({
  "_themeLabel": "상자 테마",
  "_layout_default": "기본 레이아웃",
  "_layout_top": "상단 레이아웃"
});